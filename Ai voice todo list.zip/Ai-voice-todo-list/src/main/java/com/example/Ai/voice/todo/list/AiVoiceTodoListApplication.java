package com.example.Ai.voice.todo.list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiVoiceTodoListApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiVoiceTodoListApplication.class, args);
	}

}
