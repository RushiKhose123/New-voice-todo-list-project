package com.example.Ai.voice.todo.list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiVoiceTodoListApplicationTests {

	@Test
	void contextLoads() {
	}

}
